# Portable datadir — wallet.dat and chain live here.
